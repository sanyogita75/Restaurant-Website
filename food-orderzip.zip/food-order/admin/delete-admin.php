<?php



//include constant filr
include('../config/constants.php');
   //1.get id
 $id =$_GET['id'];
   
 //2.create sql querry
 $sql="DELETE FROM tbl_admin WHERE id=$id ";
 //exxecute
 $res=mysqli_query($conn ,$sql);

 //check query
 if($res==TRUE){
     
    //echo "Admin Deleted"
    //querry excuted and ad deleted

    //create session 
    $_SESSION['delete'] = "<div class='success'>Admin deleted sucessfully :) !...</div>";
    //redirect 
    header('location:'.SITEURL.'admin/manage-admin.php');
 }
 else{
     //failed deletion
    // echo "Admin not Deleted"
    $_SESSION['delete'] = "<div class='error'>Failed To Delete Admin. Try Again Later!!...</div>";
    header('location:'.SITEURL.'admin/manage-admin.php');
 }
 //3.redirect to admin page
?>