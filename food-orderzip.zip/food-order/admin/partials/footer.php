<!-- ............footer section.......... -->
<div class="footer">
   <div class="wrapper">
      <p class="text-center">
          2021 All right reserved ,Developed by -<a href="#">Sanyogita</a></p>
       </div>
   </div>

</body>
</html>