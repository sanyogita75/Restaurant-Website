<!-- <html>
    <head>
   <title>Food order Website-Home</title>
   <link rel="stylesheet" href="../css/admin.css">
</head>

<body>
   ............menu section..........
      <div class="menu text-center">
       <div class="wrapper">
       <ul>
           <li><a href="#">Home</a></li>
           <li><a href="#">Admin</a></li>
           <li><a href="#">Category</a></li>
           <li><a href="#">Food</a></li>
           <li><a href="#">Order</a></li>
       </ul>
       </div>
      
    </div> --> 


   <?php include('partials/menu.php'); ?>
<!-- ............main content section.......... -->
   <div class="main-content">
   <div class="wrapper">
      <h1>DASHBOARD</h1>
      <div class="col-4 text-center">
          <h1>5</h1><br>
          Categories
      </div>

      <div class="col-4 text-center">
          <h1>5</h1><br>
          Categories
      </div>

      <div class="col-4 text-center">
          <h1>5</h1><br>
          Categories
      </div>

      <div class="col-4 text-center">
          <h1>5</h1><br>
          Categories
      </div>

     <div class="clear-fix"></div>
       </div>
   </div>

<?php include('partials/footer.php')?>

  







   <!-- ............footer section..........
   <div class="footer">
   <div class="wrapper">
      <p class="text-center">
          2021 All right reserved ,Developed by -<a href="#">Sanyogita</a></p>
       </div>
   </div>

</body>
</html> -->