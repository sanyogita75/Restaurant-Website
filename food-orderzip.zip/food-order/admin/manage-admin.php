<!-- <html>
    <head>
   <title>Food order Website-Home</title>
   <link rel="stylesheet" href="../css/admin.css">
</head>

<body>
 
   <div class="menu text-center">
       <div class="wrapper">
       <ul>
           <li><a href="#">Home</a></li>
           <li><a href="#">Admin</a></li>
           <li><a href="#">Category</a></li>
           <li><a href="#">Food</a></li>
           <li><a href="#">Order</a></li>
       </ul>
       </div>
      
   </div> -->

   <!-- we are inserted commonly / repeatedely used code in parial menu and footeer.php files so i am for understandinng just comment it  -->
   <?php include('partials/menu.php') ?>
<!-- ............main content section.......... -->
   <div class="main-content">
   <div class="wrapper">
      <h1>Manage Admin</h1>
      <br/>    
      <?php 
      if(isset($_SESSION['add'])){
         echo $_SESSION['add'];  //display
         unset($_SESSION['add']);  //removing
      }
      if(isset($_SESSION['delete'])){
         echo $_SESSION['delete'];  //display
         unset($_SESSION['delete']); 

      }
      if(isset($_SESSION['update']))
      {
         echo $_SESSION['update'];  //display
         unset($_SESSION['update']); 

      }
      if(isset($_SESSION['user-not-found']))
      {
         echo $_SESSION['user-not-found'];  //display
         unset($_SESSION['user-not-found']); 

      }
      if(isset($_SESSION['pwd-not-match']))
      {
         echo $_SESSION['pwd-not-match'];  //display
         unset($_SESSION['pwd-not-match']); 

      }

      if(isset($_SESSION['change-pwd']))
      {
         echo $_SESSION['change-pwd'];  //display
         unset($_SESSION['change-pwd']); 
         

      }
      ?>


<br> <br><br>
      <!-- button to add admin -->
      <a href="add-admin.php" class="btn-primary">Add Admin</a>
      <br/> <br/> <br/>
      <table class="tbl-full">
        <tr>
           <th>S.N</th>
           <th>Full Name</th>
           <th>Username</th>
           <th>Actions</th>
        </tr>






        <!-- //from database -->
        <?php 
         $sql = "SELECT *FROM tbl_admin";
         $res = mysqli_query($conn,$sql);

         //check query is execurted
         if($res==TRUE){
            //count rows to check whether data is in database
            $count= mysqli_num_rows($res); // function to get all rows in databse

             $sn=1;//var create and assign value
            if($count>0){
               //
               while($rows=mysqli_fetch_assoc($res))
               {
                  $id=$rows['id'];
                  $full_name=$rows['full_name'];
                  $username=$rows['username'];



                  //dispaly value in table


                  ?>
                   <tr>
           <td><?php echo $sn++;?>.</td>
           <td><?php echo $full_name ?></td>
           <td><?php echo $username ?></td>
           <td>
           <a href="<?php echo SITEURL;?>admin/update-password.php?id=<?php echo $id; ?>"class="btn-primary">Change Password</a>
             <a href="<?php echo SITEURL;?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary">Update Admin</a>
             <a href="<?php echo SITEURL;?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-denger">Delete Admin</a>
           </td>
        </tr>

                  <?php
               }
            }
            else{
               //not data in db
            }
         }
        
        ?>

        <!-- <tr>
           <td>1.</td>
           <td>Sanyogita</td>
           <td>sanyogitalondhe</td>
           <td>
             <a href="#" class="btn-secondary">Update Admin</a>
             <a href="#" class="btn-denger">Delete Admin</a>
           </td>
        </tr>

        <tr>
           <td>2.</td>
           <td>Sanyogita</td>
           <td>sanyogitalondhe</td>
           <td>
           <a href="#" class="btn-secondary">Update Admin</a>
             <a href="#" class="btn-denger">Delete Admin</a>
           </td>
        </tr>

        <tr>
           <td>3.</td>
           <td>Sanyogita</td>
           <td>sanyogitalondhe</td>
           <td>
           <a href="#" class="btn-secondary">Update Admin</a>
             <a href="#" class="btn-denger">Delete Admin</a>
           </td>
        </tr> -->
     </table>

    
       </div>
   </div>
   <!-- <div class="clear-fix"></div> -->
<!-- ............footer section.......... -->
   <!-- <div class="footer">
   <div class="wrapper">
      <p class="text-center">
          2021 All right reserved ,Developed by -<a href="#">Sanyogita</a></p>
       </div>
   </div>

</body>
</html> -->
<?php include('partials/footer.php')?>