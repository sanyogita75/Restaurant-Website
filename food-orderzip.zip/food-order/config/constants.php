<?php 


//lets start session
session_start();


//create constrant foe non repeation

define('SITEURL','http://localhost/food-order/');
define('LOCALHOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','food-order');



//3 excute query and save database
$conn = mysqli_connect(LOCALHOST,DB_USERNAME , DB_PASSWORD) or die(mysqli_error());//database connection
$db_select = mysqli_select_db($conn ,DB_NAME) or die(mysquli_error());//selecting db
//$res = mysqli_query($conn , $sql) or die(mysqli_error());

?>